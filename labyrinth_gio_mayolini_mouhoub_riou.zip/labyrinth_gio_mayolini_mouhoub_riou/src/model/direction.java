package model;

public enum direction {
	North, East, South, West;
}
